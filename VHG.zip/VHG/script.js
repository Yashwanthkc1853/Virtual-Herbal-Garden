document.addEventListener("DOMContentLoaded", () => {
    const featuresSection = document.querySelector(".features-section");
  
    const revealOnScroll = () => {
      const sectionTop = featuresSection.getBoundingClientRect().top;
      const windowHeight = window.innerHeight;
  
      if (sectionTop < windowHeight - 50) { // Adjust threshold as needed
        featuresSection.classList.add("show");
      }
    };
  
    window.addEventListener("scroll", revealOnScroll);
  });
  // main.js

