const { MongoClient } = require("mongodb");

const uri = "mongodb+srv://<username>:<password>@cluster.mongodb.net/plants_database?retryWrites=true&w=majority";

const client = new MongoClient(uri);

async function connectDB() {
    try {
        // Connect to MongoDB
        await client.connect();
        console.log("Connected to MongoDB"); // Connection success message
        
        // Access the database and collection
        const database = client.db("plants_database");
        const plants = database.collection("plants");

        // Fetch and log all documents in the collection
        const plantList = await plants.find({}).toArray();
        console.log("Plants:", plantList);
    } catch (error) {
        console.error("Error connecting to MongoDB:", error);
    } finally {
        // Ensure the client is closed after operations
        await client.close();
    }
}

// Call the function to test the connection
connectDB();
